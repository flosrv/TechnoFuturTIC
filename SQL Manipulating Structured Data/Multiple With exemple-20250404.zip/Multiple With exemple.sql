USE DDSLIDE
GO

/**
Simple exemple pour les requ�tes corr�l�es qui montre que m�me si je pars de la m�me table, puisque j'utilise
2 colonnes qui viennent d'un contexte de cr�ation diff�rent, je ne suis pas dans une requ�te corr�l�e
**/
SELECT S1.last_name, S1.year_result
FROM student S1
WHERE S1.year_result IN (
	SELECT MAX(S2.year_result)
	FROM student S2
	GROUP BY S2.section_id
)

/**
Il est tout � fait possible de cr�er plusieurs table avec with qui n'existent ue pendant l'ex�cution
de la requ�te SELECT � laquelle elles sont li�es.
**/
WITH 
	tb1 (lastname, firstname) 
	AS ( SELECT 'Michel', 'Ethienne'),

	tb2 (lastname, age, size)
	AS ( SELECT 'Michel2', 13, 176 )

SELECT *
	FROM tb2, tb1